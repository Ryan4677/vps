import json
import pysubs2
import subprocess
import os

def milliseconds_to_seconds(ms):
    """Konversi milidetik ke detik"""
    return ms / 1000

def get_transcript_for_segment(data, segment_id):
    """
    Ambil transcript yang sesuai dengan segment berdasarkan start dan stop
    """
    # Cari segment berdasarkan segment_id
    segment = None
    for candidate in data['candidates']:
        if candidate['segment_id'] == segment_id:
            segment = candidate
            break
    
    if not segment:
        print(f"Segment {segment_id} tidak ditemukan!")
        return [], 0, 0
    
    segment_start = segment['start']
    segment_stop = segment['stop']
    
    print(f"Segment {segment_id}: {segment['title']}")
    print(f"Start: {segment_start}ms ({milliseconds_to_seconds(segment_start)}s)")
    print(f"Stop: {segment_stop}ms ({milliseconds_to_seconds(segment_stop)}s)")
    print(f"Duration: {segment['duration']}ms\n")
    
    # Filter transcript yang berada dalam range segment
    filtered_transcript = []
    for trans in data['transcript']:
        # Cek apakah transcript berada dalam range segment
        if trans['start'] >= segment_start and trans['stop'] <= segment_stop:
            filtered_transcript.append(trans)
    
    print(f"Ditemukan {len(filtered_transcript)} subtitle dalam segment ini\n")
    return filtered_transcript, segment_start, segment_stop

def create_ass_subtitle(transcript_data, segment_start, output_ass_path):
    """
    Buat file subtitle ASS menggunakan pysubs2
    """
    # Buat SSAFile baru
    subs = pysubs2.SSAFile()
    
    # Buat style custom untuk subtitle
    style = pysubs2.SSAStyle()
    style.fontname = "Arial"
    style.fontsize = 40
    style.bold = True
    style.primary_color = pysubs2.Color(255, 255, 255)  # Putih
    style.back_color = pysubs2.Color(0, 0, 0, 128)  # Hitam semi-transparent
    style.outline_color = pysubs2.Color(0, 0, 0)  # Border hitam
    style.outline = 2  # Ketebalan border
    style.shadow = 1  # Shadow
    style.alignment = 2  # Bottom center (1-9, seperti numpad)
    style.margin_v = 30  # Margin dari bawah
    
    subs.styles["Default"] = style
    
    # Tambahkan setiap transcript sebagai event
    for trans in transcript_data:
        # Hitung waktu relatif terhadap segment start
        relative_start = trans['start'] - segment_start
        relative_stop = trans['stop'] - segment_start
        
        # Buat event (subtitle entry)
        event = pysubs2.SSAEvent(
            start=relative_start,  # pysubs2 menggunakan milliseconds
            end=relative_stop,
            text=trans['text'],
            style="Default"
        )
        subs.events.append(event)
    
    # Simpan sebagai file ASS
    subs.save(output_ass_path)
    print(f"✓ File subtitle berhasil dibuat: {output_ass_path}")

def add_subtitles_to_video_ffmpeg(video_path, ass_path, output_path):
    """
    Burn subtitle ke video menggunakan FFmpeg
    """
    print(f"\nMemproses video dengan FFmpeg...")
    print(f"Input video: {video_path}")
    print(f"Subtitle file: {ass_path}")
    print(f"Output video: {output_path}")
    
    # Escape path untuk Windows (ganti backslash dengan forward slash dan escape colon)
    ass_path_escaped = ass_path.replace('\\', '/').replace(':', '\\:')
    
    # Command FFmpeg untuk burn subtitle
    command = [
        'ffmpeg',
        '-i', video_path,
        '-vf', f"ass={ass_path_escaped}",
        '-c:a', 'copy',  # Copy audio tanpa re-encode
        '-y',  # Overwrite output file jika ada
        output_path
    ]
    
    try:
        # Jalankan FFmpeg
        result = subprocess.run(
            command,
            check=True,
            capture_output=True,
            text=True
        )
        print(f"\n✓ Video dengan subtitle berhasil dibuat: {output_path}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"\n✗ Error saat menjalankan FFmpeg:")
        print(f"Error output: {e.stderr}")
        return False
    except FileNotFoundError:
        print("\n✗ Error: FFmpeg tidak ditemukan!")
        print("Pastikan FFmpeg sudah terinstall dan ada di PATH")
        return False

def load_json_from_file(json_path):
    """
    Load data JSON dari file
    """
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        print(f"✓ Berhasil membaca file: {json_path}\n")
        return data
    except FileNotFoundError:
        print(f"✗ Error: File {json_path} tidak ditemukan!")
        return None
    except json.JSONDecodeError as e:
        print(f"✗ Error: File JSON tidak valid! {e}")
        return None

def add_subtitles_to_video(video_path, json_data, segment_id, output_path, use_full_video=False):
    """
    Tambahkan subtitle ke video berdasarkan segment yang dipilih
    
    Parameters:
    - use_full_video: True jika video adalah video lengkap yang perlu dipotong
                      False jika video sudah berupa clip segment
    """
    # Parse JSON jika masih string
    if isinstance(json_data, str):
        data = json.loads(json_data)
    else:
        data = json_data
    
    # Ambil transcript untuk segment
    transcript_data, segment_start, segment_stop = get_transcript_for_segment(data, segment_id)
    
    if not transcript_data:
        print("Tidak ada subtitle untuk ditambahkan!")
        return
    
    # Tentukan video yang akan diproses
    video_to_process = video_path
    segment_start_for_subtitle = segment_start
    
    # Jika use_full_video, potong video terlebih dahulu
    if use_full_video:
        segment_start_sec = milliseconds_to_seconds(segment_start)
        segment_stop_sec = milliseconds_to_seconds(segment_stop)
        
        print(f"Memotong video dari {segment_start_sec}s sampai {segment_stop_sec}s...")
        
        # Buat temporary video yang sudah dipotong
        temp_video = "temp_cut_video.mp4"
        
        cut_command = [
            'ffmpeg',
            '-i', video_path,
            '-ss', str(segment_start_sec),
            '-to', str(segment_stop_sec),
            '-c', 'copy',
            '-y',
            temp_video
        ]
        
        try:
            subprocess.run(cut_command, check=True, capture_output=True)
            video_to_process = temp_video
            segment_start_for_subtitle = 0  # Reset karena video dimulai dari 0
            print(f"✓ Video berhasil dipotong: {temp_video}")
        except subprocess.CalledProcessError as e:
            print(f"✗ Error saat memotong video: {e}")
            return
    else:
        print("Video sudah berupa clip segment, tidak perlu dipotong...")
        segment_start_for_subtitle = 0
    
    # Buat file subtitle ASS
    ass_file = "temp_subtitle.ass"
    print("\nMembuat file subtitle...")
    create_ass_subtitle(transcript_data, segment_start, ass_file)
    
    # Burn subtitle ke video menggunakan FFmpeg
    success = add_subtitles_to_video_ffmpeg(video_to_process, ass_file, output_path)
    
    # Cleanup temporary files
    if use_full_video and os.path.exists("temp_cut_video.mp4"):
        os.remove("temp_cut_video.mp4")
        print("✓ File temporary video dihapus")
    
    if os.path.exists(ass_file):
        os.remove(ass_file)
        print("✓ File temporary subtitle dihapus")
    
    if success:
        print(f"\n{'='*50}")
        print("SELESAI!")
        print(f"{'='*50}")

# Contoh penggunaan
if __name__ == "__main__":
    # Path file
    json_file = "output/4c24febd-247f-400a-aba6-4b1fc36fd488/metadata/metadata.json"
    input_video = "output/4c24febd-247f-400a-aba6-4b1fc36fd488/video/output/clips/clip_001_final.mp4"
    output_video = "output_with_subtitles.mp4"
    
    # Pilih segment (1-5)
    SEGMENT = 1
    
    # Load data JSON dari file
    print("=" * 50)
    print("VIDEO SUBTITLE GENERATOR")
    print("=" * 50)
    json_data = load_json_from_file(json_file)
    
    if json_data:
        # Jalankan
        add_subtitles_to_video(input_video, json_data, SEGMENT, output_video, use_full_video=False)
    else:
        print("Program dihentikan karena error membaca file JSON.")